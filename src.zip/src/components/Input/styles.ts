import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
    // Estilo base do campo de texto.
    container: {
        backgroundColor: '#ffffff',
        height: 48,
        width: '85%',
        padding: 10,
        borderRadius: 8,
        borderWidth: 1,
        borderColor: '#ffffff',
    }
}) 
